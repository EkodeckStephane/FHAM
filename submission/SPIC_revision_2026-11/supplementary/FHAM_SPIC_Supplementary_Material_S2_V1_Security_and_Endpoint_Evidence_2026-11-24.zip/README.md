# V1 security and endpoint-observation evidence

This companion archive provides implementation, analysis scripts, and trial-level evidence for the V1 authenticated-record and network-observation results reported in the revised manuscript and Supplementary Material S1.

Security outputs cover protocol mutations, altered record bits, message-integrity attempts, replay/restart/rollback trials, and record-size comparisons. Transport outputs cover four local TCP/TLS endpoint profiles and a grouped comparison with the available TLS reference corpus. Endpoint measurements are socket/TLS observations, not packet-capture results.

The held-out AUC of 1.00 applies to the specified profiles, features, splits, and reference flows. Image-only classification under message-conditioned cover selection remains outside these results. Replay and rollback findings assume an external monotonic epoch. Physical key zeroization and production key provisioning are not established by the prototype.

Reproduction entry points: `scripts/run_step2_security.py`, `scripts/analyze_step2_endpoint_detectability.py`, and `scripts/analyze_step2_tls_reference_detectability.py`. The protocol regression suite is `tests/test_v1_protocol.py`. Third-party raw capture payloads are not redistributed.
